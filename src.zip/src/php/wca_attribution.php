<p style="font-size: 1rem; text-align: center; align-self: center; color: var(--gray-300);">
    Based on WCA data as of Oct 9, 2023
</p>