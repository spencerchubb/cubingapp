<button class="btn-transparent" style="padding: 0;">
    <svg
        id="menuIcon"
        style="width: 48px; height: 48px; padding: 6px;"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round">
        <line x1="3" y1="5" x2="21" y2="5"></line>
        <line x1="3" y1="12" x2="21" y2="12"></line>
        <line x1="3" y1="19" x2="21" y2="19"></line>
    </svg>
</button>