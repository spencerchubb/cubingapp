function r(n){return n[t(n.length)]}function t(n){return Math.floor(Math.random()*n)}export{r};
