import{S as i,i as n,s as l,c as m,m as h,t as p,a as u,d as c,e as g,b as f,n as L,f as d}from"../analytics-7d83acc4.js";import{A as y}from"../AlgSetPage-21ad9ede.js";import{a as b}from"../OLL-070b20d1.js";import"../SelectOrientation-84c5ccea.js";import"../scene-a5bed2b7.js";import"../colors-9b876a92.js";import"../keyBindings-6d509829.js";import"../PlayIcon-1801a3b3.js";import"../PageSkeleton-d527636a.js";import"../rand-8b686952.js";import"../pieces-7ff17c12.js";function F(s){let t;return{c(){t=g("div"),t.innerHTML=`<h1>OLL Algorithms</h1> 
        <p>Orientation of Last Layer (also called OLL) is the third step of the CFOP Rubik&#39;s Cube method.
            CFOP stands for Cross, F2L, OLL, and PLL.</p> 
        <p>These algorithms are used to orient the last layer of the Rubik&#39;s Cube.
            That means if you start by solving the white cross, the goal of OLL is to get all the yellow stickers on top.</p> 
        <p>OLL has 57 algorithms, and that number can sound scary but it&#39;s not that bad.
            You may know 9 of the algorithms already if you have learn 2-Look OLL, so that can cut the total down to 48 algorithms.</p> 
        <p>Here are 3 more tips to help you learn the algorithms:</p> 
        <ol><li>Many cases are symmetrical, so you can use mirrors and inverses to learn the algorithms more easily.
                For example, if you know F R U R&#39; U&#39; F&#39;, it is easier to learn F U R U&#39; R&#39; F&#39; because it is just the backwards version.</li> 
            <li>Break the algorithms into triggers.
                For example, R U R&#39; U&#39; is a common trigger.
                The algorithm F R U R&#39; U&#39; R U R&#39; U&#39; F&#39; is just F, followed by the trigger twice, followed by F&#39;.</li> 
            <li>Use the <a href="/train.html" class="link">CubingApp algorithm trainer</a></li></ol> 
        <h2>Cubers also use</h2> 
        <a href="/algorithms/F2L" class="link also-use">F2L</a> 
        <a href="/algorithms/PLL" class="link also-use">PLL</a>`},m(a,e){f(a,t,e)},p:L,d(a){a&&d(t)}}}function $(s){let t,a;return t=new y({props:{algSet:b,$$slots:{default:[F]},$$scope:{ctx:s}}}),{c(){m(t.$$.fragment)},m(e,o){h(t,e,o),a=!0},p(e,[o]){const r={};o&1&&(r.$$scope={dirty:o,ctx:e}),t.$set(r)},i(e){a||(p(t.$$.fragment,e),a=!0)},o(e){u(t.$$.fragment,e),a=!1},d(e){c(t,e)}}}class R extends i{constructor(t){super(),n(this,t,null,$,l,{})}}new R({target:document.body});
