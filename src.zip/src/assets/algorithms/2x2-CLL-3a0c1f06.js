import{S as n,i,s as l,c as m,m as u,t as f,a as c,d as p,e as h,b as g,n as d,f as L}from"../analytics-7d83acc4.js";import{A as _}from"../AlgSetPage-21ad9ede.js";import{a as $}from"../2x2-CLL-454cc877.js";import"../SelectOrientation-84c5ccea.js";import"../scene-a5bed2b7.js";import"../colors-9b876a92.js";import"../keyBindings-6d509829.js";import"../PlayIcon-1801a3b3.js";import"../PageSkeleton-d527636a.js";import"../rand-8b686952.js";function x(a){let e;return{c(){e=h("div"),e.innerHTML=`<h1>2x2 CLL Algorithms</h1> 
        <p>2x2 CLL stands for Corners of Last Layer, and it is used to solve the last layer of the 2x2 Rubik&#39;s Cube.
            This algorithm set is for cubers who want to take 2x2 more seriously.
            With CLL, you&#39;ll be able to solve the last layer in one step instead of two.</p> 
        <p>After CLL, you can also learn EG1 and EG2.
            These algorithm sets are used to solve the cube after solving the first face (NOT the first layer).
            Solving one face is a lot less restrictive than solving one layer, so this leads to more efficient solutions.
            If you want to become a 2x2 master, you should start with CLL, then progress to EG1 and EG2.</p> 
        <h2>Cubers also use</h2> 
        <a href="/algorithms/2x2-EG1" class="link also-use">2x2 EG1</a> 
        <a href="/algorithms/2x2-EG2" class="link also-use">2x2 EG2</a>`},m(s,t){g(s,e,t)},p:d,d(s){s&&L(e)}}}function y(a){let e,s;return e=new _({props:{algSet:$,$$slots:{default:[x]},$$scope:{ctx:a}}}),{c(){m(e.$$.fragment)},m(t,o){u(e,t,o),s=!0},p(t,[o]){const r={};o&1&&(r.$$scope={dirty:o,ctx:t}),e.$set(r)},i(t){s||(f(e.$$.fragment,t),s=!0)},o(t){c(e.$$.fragment,t),s=!1},d(t){p(e,t)}}}class b extends n{constructor(e){super(),i(this,e,null,y,l,{})}}new b({target:document.body});
