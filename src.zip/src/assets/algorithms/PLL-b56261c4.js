import{S as i,i as n,s as l,c as h,m as u,t as m,a as p,d as c,e as d,b as L,n as f,f as g}from"../analytics-7d83acc4.js";import{A as b}from"../AlgSetPage-21ad9ede.js";import{a as y}from"../PLL-3bcf71f6.js";import"../SelectOrientation-84c5ccea.js";import"../scene-a5bed2b7.js";import"../colors-9b876a92.js";import"../keyBindings-6d509829.js";import"../PlayIcon-1801a3b3.js";import"../PageSkeleton-d527636a.js";import"../rand-8b686952.js";function P(a){let e;return{c(){e=d("div"),e.innerHTML=`<h1>PLL Algorithms</h1> 
        <p>Permutation of Last Layer (also called PLL) is the last step of the CFOP Rubik&#39;s Cube method.
            CFOP stands for Cross, F2L, OLL, and PLL.</p> 
        <p>Up to this point, the first two layers should be solved, and the last layer should be oriented.
            After PLL, the entire Rubik&#39;s Cube should be solved.</p> 
        <p>PLL has 21 algorithms, so it has less algorithms than OLL.
            Most cubers recommend learning PLL before OLL because you only need to learn 21 algorithms to improve your times.</p> 
        <p>Check out the <a href="/train.html" class="link">CubingApp algorithm trainer</a> if you want to memorize the algorithms as easily as possible.</p> 
        <p>For advanced cubers, there are more technique to learn beyond the standard 21 algorithms.</p> 
        <ul><li>Two-sided PLL recognition: Determine the PLL case only using the two sides that are facing you.
                If you have to look at multiple sides, it will naturally take longer, so advanced cubers prefer to spot the case only using two sides.</li> 
            <li>AUF prediction: Anticipate what the AUF (Adjust U Face) is going to be.
                After executing PLL, you may have to do a U/U&#39;/U2 to adjust the U face.
                Cubers prefer to predict the AUF before or while executing PLL so they don&#39;t have to spend time thinking about what it will be.</li></ul> 
        <h2>Cubers also use</h2> 
        <a href="/algorithms/F2L" class="link also-use">F2L</a> 
        <a href="/algorithms/OLL" class="link also-use">OLL</a>`},m(o,t){L(o,e,t)},p:f,d(o){o&&g(e)}}}function $(a){let e,o;return e=new b({props:{algSet:y,$$slots:{default:[P]},$$scope:{ctx:a}}}),{c(){h(e.$$.fragment)},m(t,s){u(e,t,s),o=!0},p(t,[s]){const r={};s&1&&(r.$$scope={dirty:s,ctx:t}),e.$set(r)},i(t){o||(m(e.$$.fragment,t),o=!0)},o(t){p(e.$$.fragment,t),o=!1},d(t){c(e,t)}}}class w extends i{constructor(e){super(),n(this,e,null,$,l,{})}}new w({target:document.body});
