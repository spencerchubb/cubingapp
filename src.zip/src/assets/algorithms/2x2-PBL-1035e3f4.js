import{S as n,i,s as l,c as h,m,t as p,a as d,d as c,e as f,b as u,n as g,f as y}from"../analytics-7d83acc4.js";import{A as _}from"../AlgSetPage-21ad9ede.js";import{a as $}from"../2x2-PBL-52e052b4.js";import"../SelectOrientation-84c5ccea.js";import"../scene-a5bed2b7.js";import"../colors-9b876a92.js";import"../keyBindings-6d509829.js";import"../PlayIcon-1801a3b3.js";import"../PageSkeleton-d527636a.js";import"../rand-8b686952.js";function x(s){let e;return{c(){e=f("div"),e.innerHTML=`<h1>2x2 PBL Algorithms</h1> 
        <p>PBL stands for Permutation of Both Layers, and it is the third step of the Ortega method.
            Ortega is a good intermediate method for 2x2 solvers who have already learned the beginner method.</p> 
        <p>Here is how the Ortega method works:</p> 
        <p>Typically in the beginner method, you start with the first layer.
            In the Ortega method, you just start with a face, or in other words, the first layer doesn&#39;t have to be permuted correctly.
            The second step of Ortega is to orient the last layer, and lastly, you do PBL to finish the 2x2.</p> 
        <p>PBL only has 6 cases, and you may already know 2 of the cases from other methods: J Perm and Y Perm.
            For this reason, PBL is a very easy algorithm set to learn.</p> 
        <h2>Cubers also use</h2> 
        <a href="/algorithms/2x2-CLL" class="link also-use">2x2 CLL</a> 
        <a href="/algorithms/2x2-EG1" class="link also-use">2x2 EG1</a> 
        <a href="/algorithms/2x2-EG2" class="link also-use">2x2 EG2</a>`},m(a,t){u(a,e,t)},p:g,d(a){a&&y(e)}}}function L(s){let e,a;return e=new _({props:{algSet:$,$$slots:{default:[x]},$$scope:{ctx:s}}}),{c(){h(e.$$.fragment)},m(t,o){m(e,t,o),a=!0},p(t,[o]){const r={};o&1&&(r.$$scope={dirty:o,ctx:t}),e.$set(r)},i(t){a||(p(e.$$.fragment,t),a=!0)},o(t){d(e.$$.fragment,t),a=!1},d(t){c(e,t)}}}class P extends n{constructor(e){super(),i(this,e,null,L,l,{})}}new P({target:document.body});
