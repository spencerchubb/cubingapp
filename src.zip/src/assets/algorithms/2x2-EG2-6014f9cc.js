import{S as n,i,s as l,c as m,m as c,t as p,a as h,d as u,e as f,b as g,n as d,f as _}from"../analytics-7d83acc4.js";import{A as $}from"../AlgSetPage-21ad9ede.js";import{a as E}from"../2x2-EG2-51e4afbd.js";import"../SelectOrientation-84c5ccea.js";import"../scene-a5bed2b7.js";import"../colors-9b876a92.js";import"../keyBindings-6d509829.js";import"../PlayIcon-1801a3b3.js";import"../PageSkeleton-d527636a.js";import"../rand-8b686952.js";function G(o){let e;return{c(){e=f("div"),e.innerHTML=`<h1>2x2 EG2 Algorithms</h1> 
        <p>EG2 is commonly learned after EG1. CLL, EG1, and EG2 go hand in hand. These three algorithm sets will allow you to solve the entire cube after solving one face.</p> 
        <p>CLL: First layer is solved. This occurs 1/6th of the time<br/>
            EG1: First layer has an adjacent swap. This occurs 4/6th of the time<br/>
            EG2: First layer has a diagonal swap. This occurs 1/6th of the time</p> 
        <h2>Cubers also use</h2> 
        <a href="/algorithms/2x2-CLL" class="link also-use">2x2 CLL</a> 
        <a href="/algorithms/2x2-EG1" class="link also-use">2x2 EG1</a>`},m(a,t){g(a,e,t)},p:d,d(a){a&&_(e)}}}function L(o){let e,a;return e=new $({props:{algSet:E,$$slots:{default:[G]},$$scope:{ctx:o}}}),{c(){m(e.$$.fragment)},m(t,s){c(e,t,s),a=!0},p(t,[s]){const r={};s&1&&(r.$$scope={dirty:s,ctx:t}),e.$set(r)},i(t){a||(p(e.$$.fragment,t),a=!0)},o(t){h(e.$$.fragment,t),a=!1},d(t){u(e,t)}}}class x extends n{constructor(e){super(),i(this,e,null,L,l,{})}}new x({target:document.body});
