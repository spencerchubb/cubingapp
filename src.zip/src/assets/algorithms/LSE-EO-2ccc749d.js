import{S as n,i,s as l,c as p,m,t as c,a as u,d as g,e as d,b as f,n as h,f as E}from"../analytics-7d83acc4.js";import{A as L}from"../AlgSetPage-21ad9ede.js";import{a as S}from"../LSE-EO-32bc7148.js";import"../SelectOrientation-84c5ccea.js";import"../scene-a5bed2b7.js";import"../colors-9b876a92.js";import"../keyBindings-6d509829.js";import"../PlayIcon-1801a3b3.js";import"../PageSkeleton-d527636a.js";import"../rand-8b686952.js";function $(o){let e;return{c(){e=d("div"),e.innerHTML=`<h1>LSE EO Algorithms</h1> 
        <p>Last Six Edges Edge Orientation (LSE EO) is a substep of the Roux method. Since LSE is the 4th step, the substeps are typically called 4a, 4b, and 4c. This algorithm set is for substep 4a.</p> 
        <p>4a: Edge orientation (EO)<br/>
            4b: Solve upper left and upper right edges (ULUR)<br/>
            4c: Solve middle edges</p> 
        <h2>Cubers also use</h2> 
        <a href="/algorithms/LSE-EOLR" class="link also-use">LSE EOLR</a> 
        <a href="/algorithms/CMLL" class="link also-use">CMLL</a>`},m(s,t){f(s,e,t)},p:h,d(s){s&&E(e)}}}function _(o){let e,s;return e=new L({props:{algSet:S,$$slots:{default:[$]},$$scope:{ctx:o}}}),{c(){p(e.$$.fragment)},m(t,a){m(e,t,a),s=!0},p(t,[a]){const r={};a&1&&(r.$$scope={dirty:a,ctx:t}),e.$set(r)},i(t){s||(c(e.$$.fragment,t),s=!0)},o(t){u(e.$$.fragment,t),s=!1},d(t){g(e,t)}}}class b extends n{constructor(e){super(),i(this,e,null,_,l,{})}}new b({target:document.body});
