<!DOCTYPE html>
<html>
<head>
    <meta name="description" content="Rubik's Cube algorithm database with 4,000 algorithms">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/colors.css">
    <link rel="icon" href="/assets/favicon.svg" type="image/x-icon">
    <title>Rubik's Cube Algorithms</title>
</head>

<style>
    .line-breaks {
        white-space: pre-line;
    }

    iframe {
        border: none;
    }
</style>

<body style="width: 100%; height: 100%; overflow-y: auto;">
    <nav>
        <?php include_once "php/menu/menuIcon.php" ?>
        <?php include_once "php/menu/menu.php" ?>
    </nav>
    <main style="width: 100%; padding: 0 16px;">
        <h1 style="margin-top: 24px;">UF/UFR 3-style</h1>
        <p class="line-breaks" style="margin-top: 16px;">3-Style uses intuitive commutators to cycle 3 pieces at once. One of these pieces is always the buffer, so you can solve 2 letters with each algorithm.
        
        This is the method that the fastest blindfolded solvers in the world use. Currently, the fastest solvers average under 20 seconds!</p>
        <div style="margin-top: 24px;">
            <iframe width="100%" height="400px" src="https://docs.google.com/spreadsheets/d/e/2PACX-1vRBkOvZr2KgBCQYgLjRgbksLjSCLNRHerqKRMYdiF_NTyzK6b8Q_-WYfCVWrKNuPCbKpy4za-BC3mgH/pubhtml"></iframe>
        </div>
        <div style="margin-top: 64px;"></div>
    </main>
</body>

<?php include "php/gtag.php" ?>

</html>
